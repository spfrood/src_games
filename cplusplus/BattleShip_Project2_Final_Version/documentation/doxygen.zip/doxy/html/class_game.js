var class_game =
[
    [ "Game", "class_game.html#ad59df6562a58a614fda24622d3715b65", null ],
    [ "~Game", "class_game.html#ae3d112ca6e0e55150d2fdbc704474530", null ],
    [ "gameOn", "class_game.html#a7ebb6acddd59f76be6b0888ca52295e6", null ],
    [ "getGues", "class_game.html#a20ad0b0ce0078dc48b500ea04807d8ab", null ],
    [ "getHits", "class_game.html#a8a0b7bfc0cea9cc38dae79516cb325aa", null ],
    [ "getLast", "class_game.html#ab9f516c5cca41cf4807dc71108af4257", null ],
    [ "getShip", "class_game.html#aea2b0b27d7caacd0c5a822fc24cd9794", null ],
    [ "getShot", "class_game.html#a17a8524e3b04582d61a17133d8685ec6", null ],
    [ "getTurn", "class_game.html#af2c2fb7e28f94dda39b88ce4f7f4eec2", null ],
    [ "mapClr", "class_game.html#a35e06b7cc99e0577418a5187b4b561ca", null ],
    [ "okShot", "class_game.html#ab9025f2355418561b9e406dd4b5da02a", null ],
    [ "setMap", "class_game.html#a4e23ede628f25d35813322e4e3f46b01", null ],
    [ "setPlay", "class_game.html#a9acc18b29b10e44174bb4c0c59886469", null ],
    [ "setShip", "class_game.html#aa4612d0ad265babef74c3a1122d0a395", null ],
    [ "operator<<", "class_game.html#a7bb9176e07b6f6c73c930dba6400265f", null ],
    [ "cols", "class_game.html#a11dd2c238611d9080277e9766b48c772", null ],
    [ "lstShot", "class_game.html#afd1843aa37acf5d5c33cc7eeb1ffe88f", null ],
    [ "player", "class_game.html#a3be2e2f353ec3c6dbffff9f8557e7280", null ],
    [ "playing", "class_game.html#a42af2652c4ec21a2e6445fe866d01828", null ],
    [ "rows", "class_game.html#ae882486dec6d9507bbef7f44aaf07db5", null ],
    [ "shot", "class_game.html#aaf0b60de36091e3a4115004999e4dc7a", null ]
];