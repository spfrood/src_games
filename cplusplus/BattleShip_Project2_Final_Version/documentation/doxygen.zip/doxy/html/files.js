var files =
[
    [ "GitHubProjects", "dir_a925254867fe9d418ceac0c77fbfcfd9.html", "dir_a925254867fe9d418ceac0c77fbfcfd9" ]
];