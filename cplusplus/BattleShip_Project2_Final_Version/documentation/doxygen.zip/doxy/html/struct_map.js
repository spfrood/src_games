var struct_map =
[
    [ "guess", "struct_map.html#a60684c774a0cb6da010399a63366b1ba", null ],
    [ "guesses", "struct_map.html#a77bf60eb6e41fce7ee5ebd7582372a28", null ],
    [ "hits", "struct_map.html#a4b81caa9d402a8edc30fb93869e7163e", null ],
    [ "ship", "struct_map.html#a95d68a52f9a8a7c50c45e9ef63fe9a64", null ]
];