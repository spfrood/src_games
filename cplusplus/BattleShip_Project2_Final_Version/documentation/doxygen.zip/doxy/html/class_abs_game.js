var class_abs_game =
[
    [ "getGues", "class_abs_game.html#a740443eaf2d00365e42033fdfff43f8d", null ],
    [ "getHits", "class_abs_game.html#a038b7078fe6c66a372f1727fb4de0c6d", null ],
    [ "getShip", "class_abs_game.html#a075ff877d69ce6f7cbd4566cbd6fc3f8", null ],
    [ "getTurn", "class_abs_game.html#a5d8cca6f9d9ef2d19f6dbd632289188d", null ]
];