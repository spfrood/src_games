var main_8cpp =
[
    [ "conBord", "main_8cpp.html#a894e06ede39f535739ff6627a3156af5", null ],
    [ "locTest", "main_8cpp.html#a06368af884461c09e7818ce7f288ea74", null ],
    [ "lodGame", "main_8cpp.html#a8c4b5ea02e4218a1f1c5652cacda29d3", null ],
    [ "main", "main_8cpp.html#a3c04138a5bfe5d72780bb7e82a18e627", null ],
    [ "newBord", "main_8cpp.html#a041ff5cce4447b4a8c9225f73dd61106", null ],
    [ "putComp", "main_8cpp.html#aa189534b225de92b889d030960fd58f3", null ],
    [ "putShip", "main_8cpp.html#a8dff9b01ad1fe2279dae6236cd044ca8", null ],
    [ "savGame", "main_8cpp.html#a0d76d956009497d98f99c4b5fcd03b0e", null ]
];