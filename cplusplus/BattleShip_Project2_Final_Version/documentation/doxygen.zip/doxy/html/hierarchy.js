var hierarchy =
[
    [ "AbsGame", "class_abs_game.html", null ],
    [ "Game", "class_game.html", [
      [ "Weirdo", "class_weirdo.html", null ]
    ] ],
    [ "Guess", "class_guess.html", null ],
    [ "Map", "struct_map.html", null ]
];