var searchData=
[
  ['savgame',['savGame',['../main_8cpp.html#a0d76d956009497d98f99c4b5fcd03b0e',1,'main.cpp']]],
  ['setcol',['setCol',['../class_guess.html#a2283979520b0e7d4922241aa92f0917b',1,'Guess']]],
  ['setmap',['setMap',['../class_game.html#a4e23ede628f25d35813322e4e3f46b01',1,'Game::setMap()'],['../class_weirdo.html#aa71d633becb93a3d1b6273f5b0a8dc14',1,'Weirdo::setMap()']]],
  ['setplay',['setPlay',['../class_game.html#a9acc18b29b10e44174bb4c0c59886469',1,'Game']]],
  ['setrow',['setRow',['../class_guess.html#a14824d1a22b6d0cb328adf5b052b9529',1,'Guess']]],
  ['setship',['setShip',['../class_game.html#aa4612d0ad265babef74c3a1122d0a395',1,'Game']]],
  ['ship',['ship',['../struct_map.html#a95d68a52f9a8a7c50c45e9ef63fe9a64',1,'Map']]],
  ['shot',['shot',['../class_game.html#aaf0b60de36091e3a4115004999e4dc7a',1,'Game']]]
];
