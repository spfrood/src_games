var searchData=
[
  ['game',['Game',['../class_game.html',1,'']]],
  ['guess',['Guess',['../class_guess.html',1,'']]]
];
