var indexSectionsWithContent =
{
  0: "abcghilmnoprsuvwy~",
  1: "agmw",
  2: "v",
  3: "acgmvw",
  4: "cgilmnopsw~",
  5: "cghlprs",
  6: "o",
  7: "bcgimruwy"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "related",
  7: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Friends",
  7: "Macros"
};

