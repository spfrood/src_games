var searchData=
[
  ['cols',['cols',['../class_game.html#a11dd2c238611d9080277e9766b48c772',1,'Game']]]
];
