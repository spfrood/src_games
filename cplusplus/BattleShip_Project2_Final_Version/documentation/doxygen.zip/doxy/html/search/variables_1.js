var searchData=
[
  ['guess',['guess',['../struct_map.html#a60684c774a0cb6da010399a63366b1ba',1,'Map']]],
  ['guesses',['guesses',['../struct_map.html#a77bf60eb6e41fce7ee5ebd7582372a28',1,'Map']]]
];
