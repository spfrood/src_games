var searchData=
[
  ['absgame',['AbsGame',['../class_abs_game.html',1,'']]]
];
