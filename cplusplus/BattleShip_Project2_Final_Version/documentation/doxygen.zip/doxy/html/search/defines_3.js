var searchData=
[
  ['inverse',['INVERSE',['../colors_8h.html#ade269cc47cfaba70068f2586e898051d',1,'colors.h']]]
];
