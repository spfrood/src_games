var searchData=
[
  ['newbord',['newBord',['../main_8cpp.html#a041ff5cce4447b4a8c9225f73dd61106',1,'main.cpp']]]
];
