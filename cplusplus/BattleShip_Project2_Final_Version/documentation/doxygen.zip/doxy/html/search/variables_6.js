var searchData=
[
  ['ship',['ship',['../struct_map.html#a95d68a52f9a8a7c50c45e9ef63fe9a64',1,'Map']]],
  ['shot',['shot',['../class_game.html#aaf0b60de36091e3a4115004999e4dc7a',1,'Game']]]
];
