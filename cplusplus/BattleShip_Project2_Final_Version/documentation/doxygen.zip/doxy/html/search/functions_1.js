var searchData=
[
  ['game',['Game',['../class_game.html#ad59df6562a58a614fda24622d3715b65',1,'Game']]],
  ['gameon',['gameOn',['../class_game.html#a7ebb6acddd59f76be6b0888ca52295e6',1,'Game']]],
  ['getcol',['getCol',['../class_guess.html#ad8d68e38d81479d605977331a0e57a0a',1,'Guess']]],
  ['getgues',['getGues',['../class_abs_game.html#a740443eaf2d00365e42033fdfff43f8d',1,'AbsGame::getGues()'],['../class_game.html#a20ad0b0ce0078dc48b500ea04807d8ab',1,'Game::getGues()']]],
  ['gethits',['getHits',['../class_abs_game.html#a038b7078fe6c66a372f1727fb4de0c6d',1,'AbsGame::getHits()'],['../class_game.html#a8a0b7bfc0cea9cc38dae79516cb325aa',1,'Game::getHits()']]],
  ['getlast',['getLast',['../class_game.html#ab9f516c5cca41cf4807dc71108af4257',1,'Game']]],
  ['getrow',['getRow',['../class_guess.html#a9310375abd6a91897d51e0c78eb2d7c7',1,'Guess']]],
  ['getship',['getShip',['../class_abs_game.html#a075ff877d69ce6f7cbd4566cbd6fc3f8',1,'AbsGame::getShip()'],['../class_game.html#aea2b0b27d7caacd0c5a822fc24cd9794',1,'Game::getShip()']]],
  ['getshot',['getShot',['../class_game.html#a17a8524e3b04582d61a17133d8685ec6',1,'Game']]],
  ['getturn',['getTurn',['../class_abs_game.html#a5d8cca6f9d9ef2d19f6dbd632289188d',1,'AbsGame::getTurn()'],['../class_game.html#af2c2fb7e28f94dda39b88ce4f7f4eec2',1,'Game::getTurn()']]],
  ['guess',['Guess',['../class_guess.html#a34ed64834f2bdb9a6198ec6e5e7bdfc0',1,'Guess']]]
];
