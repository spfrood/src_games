var searchData=
[
  ['hits',['hits',['../struct_map.html#a4b81caa9d402a8edc30fb93869e7163e',1,'Map']]]
];
