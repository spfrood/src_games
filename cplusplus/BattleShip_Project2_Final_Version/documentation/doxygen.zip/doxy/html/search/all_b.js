var searchData=
[
  ['red',['RED',['../colors_8h.html#a8d23feea868a983c8c2b661e1e16972f',1,'colors.h']]],
  ['reset',['RESET',['../colors_8h.html#ab702106cf3b3e96750b6845ded4e0299',1,'colors.h']]],
  ['rows',['rows',['../class_game.html#ae882486dec6d9507bbef7f44aaf07db5',1,'Game']]]
];
