var searchData=
[
  ['player',['player',['../class_game.html#a3be2e2f353ec3c6dbffff9f8557e7280',1,'Game']]],
  ['playing',['playing',['../class_game.html#a42af2652c4ec21a2e6445fe866d01828',1,'Game']]]
];
