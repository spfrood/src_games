var annotated_dup =
[
    [ "AbsGame", "class_abs_game.html", "class_abs_game" ],
    [ "Game", "class_game.html", "class_game" ],
    [ "Guess", "class_guess.html", "class_guess" ],
    [ "Map", "struct_map.html", "struct_map" ],
    [ "Weirdo", "class_weirdo.html", "class_weirdo" ]
];