var class_guess =
[
    [ "Guess", "class_guess.html#a34ed64834f2bdb9a6198ec6e5e7bdfc0", null ],
    [ "getCol", "class_guess.html#ad8d68e38d81479d605977331a0e57a0a", null ],
    [ "getRow", "class_guess.html#a9310375abd6a91897d51e0c78eb2d7c7", null ],
    [ "setCol", "class_guess.html#a2283979520b0e7d4922241aa92f0917b", null ],
    [ "setRow", "class_guess.html#a14824d1a22b6d0cb328adf5b052b9529", null ],
    [ "operator<<", "class_guess.html#aa9dfccdd4605cf8faa55ddfa8d2c9745", null ],
    [ "operator>>", "class_guess.html#a4248aa595b925941de244395ba77ba7c", null ]
];