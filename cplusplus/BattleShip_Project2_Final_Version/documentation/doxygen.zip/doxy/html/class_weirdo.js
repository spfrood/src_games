var class_weirdo =
[
    [ "Weirdo", "class_weirdo.html#aa4da5eda496d8a5bdfa0bd2e1f4dc582", null ],
    [ "setMap", "class_weirdo.html#aa71d633becb93a3d1b6273f5b0a8dc14", null ]
];